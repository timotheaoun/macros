Set objWMPlayer = CreateObject("WMPlayer.OCX.7")
Set colCDROMs = objWMPlayer.CDROMCollection

audioFilePath = "RR.mp3"

Do
    objWMPlayer.URL = audioFilePath
    objWMPlayer.settings.autoStart = True
    objWMPlayer.settings.volume = 30
    Do While objWMPlayer.playState <> 1
        WScript.Sleep 100
    Loop
    Do While objWMPlayer.playState = 2 
        WScript.Sleep 100
    Loop
    objWMPlayer.close
    WScript.Sleep 100

Loop While True
